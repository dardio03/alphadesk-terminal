import { AggregatorSettings } from '@/types/types'

export default {
  calculateSlippage: null,
  aggregationLength: null,
  preferQuoteCurrencySize: null,
  wsProxyUrl: null,
  buckets: {}
} as AggregatorSettings
